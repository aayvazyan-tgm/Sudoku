Sudoku
======

Verarbeitet Sudokus aus csv Dateien.
